
<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
<meta charset="utf-8">
<title>100+ Web Development Projects For Students and Developers.</title>
<meta name="description" content="100+ Free projects for personal and industrial use. Download projects and integrate in your projects to 
								  ">
<meta name="keywords" content="Creative Agency, Marketing Agency">
<meta name="author" content="rajesh-doot">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="theme-color" content="#e8f1ff">

<link href="../images/faviconc.ico" rel="icon">

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/plugin.min.css" rel="stylesheet">
<link href="../css/all.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="../css/style.css" rel="stylesheet">
<link href="../css/responsive.css" rel="stylesheet">
</head>
<body>
<div class="onloadpage" id="page-load">
<div class="loader-div">
<div class="on-img"><img src="../images/loader.gif" alt="Logo" class="img-fluid"><span>Loading Please Wait...</span></div>
</div>
</div>


<?php include("header.php") ?>


<section class="r-bg-i sec-pad digi-service">
<div class="container pt60">
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="sec-heading text-center pera-block">
<h2>See What We Can <span class="ree-tt">Do</span> for <span class="ree-tt">You</span></h2>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.</p>
</div>
</div>
</div>
<div class="row mt30">
<div class="col-lg-3 col-sm-6 mt30" data-aos="fade-up" data-aos-delay="100">
<div class="ree-card bhv-tt">
<div class="creative-img reebga"><img src="images/gpt.webp" alt="App Development" class="img-fluid"></div>
<div class="creative-cntnt">
<h4 class="mb15"><a href="chatgpt">Chatgpt</a></h4>
	<p>Category:Web development</p>
<p>Light and Dark mode</p>
<a href="https://github.com/vicky87883/gpt" class="ree-card-link mt30">Source Code <i class="fas fa-arrow-right fa-btn"></i></a>
</div>
</div>
</div>
</div>
</div>
</section>

<?php include("footer.php") ?>
<script src="../js/jquery-3.6.0.min.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/app.bundle.js"></script>
<script src="../js/parallax.min.js"></script>
<script src="../js/main.js"></script>
	<script>
	document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
            alert('not allowed');
            return false;
        } else {
            return true;
        }
};
	</script>
</body>
</html>