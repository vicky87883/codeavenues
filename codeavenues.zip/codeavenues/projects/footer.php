<footer class=footer-a>
<div class="footer-fist-row pt40">
<div class=container>
<div class=footer-rowset>
<div class="col footer-head">
<h5>Contact info</h5>
<ul class="footer-links-list social-linkz">
<li><a href=tel:+919817642072><span><i class="fas fa-phone-square-alt"></i></span> +91
9817642072</a></li>
<li><a href=tel:+919817642072><span><i class="fab fa-whatsapp-square"></i></span>
+919817642072</a></li>
<li><a href=#><span><i class="fas fa-envelope"></i></span> <span class=__cf_email__>codeavenues01@gmail.com</span></a>
</li>
<li><a href=#><span><i class="fas fa-envelope"></i></span> <span class=__cf_email__>codeavenues01@gmail.com</span></a>
</li>
<li><a href=https://join.skype.com/invite/xjzWp7UDbedE><span><i class="fab fa-skype"></i></span>
codeavenues-skype</a>
</li>
</ul>
</div>
<div class="col footer-head">
<h5>Follow Us</h5>
<ul class="footer-links-list social-linkz">
<li><a href=javascript:void(0)><span><i class="fab fa-facebook-f"></i></span> Facebook</a>
</li>
<li><a href=javascript:void(0)><span><i class="fab fa-twitter"></i></span> Twitter </a>
</li>
<li><a href="https://www.instagram.com/codeavenues/"><span><i class="fab fa-instagram"></i></span> Instagram</a>
</li>
<li><a href="https://in.pinterest.com/codeavenues/"><span><i class="fab fa-pinterest-p"></i></span> Pinterest</a>
</li>
<li><a href=javascript:void(0)><span><i class="fab fa-linkedin-in"></i></span> linkedin</a>
</li>
<li><a href=javascript:void(0)><span><i class="fab fa-youtube"></i></span> Youtube</a> </li>
</ul>
</div>
<div class="col footer-head">
<h5>Languages</h5>
<ul class=footer-links-list>
<li><a href=https://www.codeavenues.com/c>C Programming</a></li>
<li><a href=https://www.codeavenues.com/c++>c++</a></li>
<li><a href=https://www.codeavenues.com/java>Java language</a></li>
<li><a href=https://www.codeavenues.com/rubyonrails>Ruby on Rails</a></li>
<li><a href=https://www.codeavenues.com/golang>GoLang</a></li>
<li><a href=https://www.codeavenues.com/lisp>Lisp structure</a></li>
</ul>
</div>
<div class="col footer-head">
<h5>Industries</h5>
<ul class=footer-links-list>
<li><a href=javascript:void(0)>Healthcare</a></li>
<li><a href=javascript:void(0)>Education</a></li>
<li><a href=javascript:void(0)>Retail</a></li>
<li><a href=javascript:void(0)>Logistics</a></li>
<li><a href=javascript:void(0)>Oil & Gas</a></li>
<li><a href=javascript:void(0)>Music & Video</a></li>
</ul>
</div>
<div class="col footer-head">
<h5>Write & Earn</h5>
<ul class=footer-links-list>
<li><a href=javascript:void(0)>Write an Article</a></li>
<li><a href=javascript:void(0)>Improve an Article</a></li>
<li><a href=javascript:void(0)>Pick Topics to Write</a></li>
<li><a href=javascript:void(0)>Write Interview Experience</a></li>
<li><a href=javascript:void(0)>Internships</a></li>
<li><a href=javascript:void(0)>Video Internship</a></li>
</ul>
</div>
</div>
</div>
<div class=container>
<div class=footer-rowset>
<div class="col footer-head">
<h5>Mathematics</h5>
<ul class="footer-links-list social-linkz">
<li><a href=https://www.codeavenues.com/maths/what-is-maths><span><i class="fab fa-wpforms"></i></span> 8TH Class(ADVANCED)</a>
</li>
<li><a href=https://www.codeavenues.com/maths/what-is-maths><span><i class="fab fa-wpforms"></i></span> 9TH Class(ADVANCED)</a>
</li>
<li><a href=https://www.codeavenues.com/maths/what-is-maths><span><i class="fab fa-wpforms"></i></span> 10TH Class(ADVANCED)</a>
</li>
<li><a href=https://www.codeavenues.com/maths/what-is-maths><span><i class="fab fa-wpforms"></i></span> 11TH Class(ADVANCED)</a>
</li>
<li><a href=https://www.codeavenues.com/maths/what-is-maths><span><i class="fab fa-wpforms"></i></span> 12TH Class(JEE)</a></li>
</ul>
</div>
<div class="col footer-head">
<h5>Algebra</h5>
<ul class="footer-links-list social-linkz">
<li><a href=javascript:void(0)>Complex Numbers</a>
</li>
<li><a href=javascript:void(0)>Quadratic Equations </a>
</li>
<li><a href=javascript:void(0)> Sequence and Series</a>
</li>
<li><a href=javascript:void(0)> Logarithm</a>
</li>
<li><a href=javascript:void(0)> Permutations and Combinations</a> </li>
</ul>
</div>
<div class="col footer-head">
<h5>Trigonometry</h5>
<ul class="footer-links-list social-linkz">
<li><a href=javascript:void(0)>Trigonometry</a>
</li>
<li><a href=javascript:void(0)>Properties of Triangle</a>
</li>
<li><a href=javascript:void(0)> Solutions of Triangle</a>
</li>
<li><a href=javascript:void(0)> Inverse Trigonometric Functions</a>
</li>
<li><a href=javascript:void(0)>Height & Distance</a>
</li>
</ul>
</div>
<div class="col footer-head">
<h5>Analytical Geometry</h5>
<ul class=footer-links-list>
<li><a href=javascript:void(0)>Straight Lines and Pair of Straight Lines
</a></li>
<li><a href=javascript:void(0)>Circle</a></li>
<li><a href=javascript:void(0)>Parabola</a></li>
<li><a href=javascript:void(0)>Ellipse</a></li>
<li><a href=javascript:void(0)>Hyperbola</a></li>
</ul>
</div>
<div class="col footer-head">
<h5>Integral Calculus</h5>
<ul class=footer-links-list>
<li><a href=javascript:void(0)>Indefinite Integrals</a></li>
<li><a href=javascript:void(0)>Definite Integrals</a></li>
<li><a href=javascript:void(0)>Area of Bounded Regions</a></li>
<li><a href=javascript:void(0)>Differential Equations</a></li>
</ul>
</div>
</div>
<div class="footer-abt mt70 pt40 pb40">
<div class=container>
<div class=row>
<div class="col-lg-3 vcenter">
<div class=footer-ree-lg>
<div class=footer-logo>
<a href=#> <img src=../images/codeavenue.png alt=reeven class=img> </a>
</div>
<div class="star-rating-review mt30">
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
</div>
<h6 class=mt10>Overall client rating is 4.9 out of 8,500 Clients for Codeavenues</h6>
</div>
</div>
<div class="col-lg-6 vcenter">
<div class=ref-logo>
<a href=#> <img src=../images/brand-logo/app-futura.png alt=Logo> </a>
<a href=#> <img src=../images/brand-logo/clutch.png alt=Logo> </a>
<a href=#> <img src=../images/brand-logo/goodfirm.png alt=Logo> </a>
<a href=#> <img src=../images/brand-logo/itfirm.png alt=Logo> </a>
</div>
</div>
<div class="col-lg-3 vcenter ft-btn">
<a href=# class="ree-btn ree-btn-grdt1 mw-80 no-shadows">Our Brochure <i class="fas fa-arrow-right fa-btn"></i></a>
</div>
</div>
</div>
</div>
<div class="container ft-cpy">
<div class=row>
<div class=col-lg-5>
<div class=ft-copyright>
<p>We are tracking any intention of piracy.</p>
</div>
</div>
<div class=col-lg-7>
<div class="ft-copyright ft-r">
<p>Copyright © 2021 Codeavenues. All rights reserved.
</p>
</div>
</div>
</div>
	</div>
</div>
</div>
</footer>