<div class="page-headings mb15" style="padding:10px;font-family:Georgia,serif">
<span class="sub-heading mb15"><i class="fas fa-book mr5"></i> Recent Blogs</span>
<h1 class=mb15>django <span class="ree-text rt40">Tutorial</span></h1>
<p>Learn Coding beginner to Advance.</p>
<h4>View our recent blogs</h4>
<form class=mt20 style=position:relative!important>
<input type=text name=subs id=subs-email placeholder="Search..." class=subs-input>
<button class="ree-btn-grdt1 subs-btn"><i class="fas fa-search"></i>
</button>
</form>
<br>
<pre style="font-family:Georgia,serif">
	
<span class="mb15"><a  href="intro"><i class="fas fa-book mr5"></i> Introduction To Django Framework </a></span><br>
<span class="mb15"><a  href="install"><i class="fas fa-book mr5"></i> Installation of Django Framework </a></span><br>
<span class="mb15"><a  href="structure"><i class="fas fa-book mr5"></i>Core Structure of Django Framework </a></span><br>
<span class="mb15"><a  href="mvc"><i class="fas fa-book mr5"></i>Model-View-Controller(MVC) in  Django Framework </a></span><br>
<span class="mb15"><a  href="api"><i class="fas fa-book mr5"></i>API-Application Programming interface in  Django Framework </a></span><br>
<span class="mb15"><a  href="installation-in-ubuntu"><i class="fas fa-book mr5"></i>Installation of Django on Ubuntu Operating System </a></span><br>
<span class="mb15"><a  href="createproject"><i class="fas fa-book mr5"></i>Create Project in Django Rest Framework </a></span><br>
<span class="mb15"><a  href="createapp"><i class="fas fa-book mr5"></i>Create First App in Django Framework </a></span><br>

</pre>
</div>