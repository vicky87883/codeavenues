<nav id="navigation-widget-small" class="navigation-widget navigation-widget-desktop closed sidebar left delayed">
<a class="user-avatar small no-outline online" href="#">
<div class="user-avatar-content">
<div class="hexagon-image-30-32" data-src="img/avatar/03.jpg"></div>
</div>
<div class="user-avatar-progress">
<div class="hexagon-progress-40-44"></div>
</div>
<div class="user-avatar-progress-border">
<div class="hexagon-border-40-44"></div>
</div>
<div class="user-avatar-badge">
<div class="user-avatar-badge-border">
<div class="hexagon-22-24"></div>
</div>
<div class="user-avatar-badge-content">
<div class="hexagon-dark-16-18"></div>
</div>
<p class="user-avatar-badge-text">24</p>
</div>
</a>
<ul class="menu small">
<li class="menu-item">
<a class="menu-item-link text-tooltip-tfr" href="community" data-title="community">
<svg class="menu-item-link-icon icon-newsfeed">
<use xlink:href="#svg-newsfeed"></use>
</svg>
</a>
</li>
<li class="menu-item">
<a class="menu-item-link text-tooltip-tfr" href="ask" data-title="message">
<svg class="menu-item-link-icon icon-group">
<use xlink:href="#svg-group"></use>
</svg>
</a>
</li>
<li class="menu-item">
<a class="menu-item-link text-tooltip-tfr" href="chat" data-title="Chat">
<svg class="menu-item-link-icon icon-forums">
<use xlink:href="#svg-forums"></use>
</svg>
</a>
</li>
</ul>
</nav>