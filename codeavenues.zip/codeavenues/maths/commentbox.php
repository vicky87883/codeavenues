<div class="row">
		<div class="col-md-6">
<div class="form-contact-hom">
<div class="form-block">
<div class="form-head">
<h4>Comment below.</h4>
</div>
<div class="form-body">
<form action="comment" method="post" name="feedback-form">
<div class="fieldsets row">
<input type="text" placeholder="Enter Your Name" name="name"> 
</div>
<div class="fieldsets row"><textarea placeholder="Message" name="message"></textarea>
</div>
<div class="fieldsets mt20"> <button type="submit" name="submit" class="ree-btn  ree-btn-grdt1 w-100">Post Your Comment<i class="fas fa-arrow-right fa-btn"></i></button> </div>
<p class="trm"><i class="fas fa-lock"></i>We hate spam, and we respect your privacy.
</p>
</form>
</div>
</div>
</div>
</div>
		<div class="col-md-6">
<div class="ree-card pera-block ree-card-content">
<h5>Name</h5>
<p>comment</p>
</div>
</div>
</div>
<br><br>