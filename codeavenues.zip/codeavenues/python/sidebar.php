<div class="page-headings mb15">
<span class="sub-heading mb15"><i class="fas fa-book mr5"></i> Recent Blogs</span>
<h1 class=mb15>Our <span class="ree-text rt40">Blog</span></h1>
<p>What would you love to learn how to do?</p>
<h4>View our recent blogs</h4>
<form class=mt20 style=position:relative!important>
<input type=text name=subs id=subs-email placeholder="Search..." class=subs-input>
<button class="ree-btn-grdt1 subs-btn"><i class="fas fa-search"></i>
</button>
</form>
<br>
<pre>
	
<span class="mb15"><a  href="fortran"><i class="fas fa-book mr5"></i> Introduction to Python</a></span><br>

</pre>
</div>